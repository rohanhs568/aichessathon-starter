# V1.5 high-impact search update

Included:
- fast TT/eval-cache keys using `Board._transposition_key()` with fallback;
- TT retains `halfmove_clock`;
- aspiration window 50 -> 160;
- fail-low panic time, max 2x normal / 7s / remaining clock less 1s;
- no panic extension at <=5s;
- aspiration diagnostics in engine logs;
- ACPL mate-artifact fix;
- installer module-import fix.

Deliberately not included:
- root hysteresis;
- partial iteration commits;
- check extension;
- SEE;
- LMR;
- evaluator retraining;
- incremental NN accumulators.

Apply from repo root:

```bash
chmod +x run_v15_high_impact_checks.sh
.venv/bin/python apply_high_impact_v15.py
./run_v15_high_impact_checks.sh
```

The patcher snapshots the pre-change engine into:

```text
baselines/v1_4b_pre_fastasp/
```

If all gates pass, the package is:

```text
submission_v1_5_fastasp.zip
```

The 12-game A/B is a deployment smoke test, not an Elo proof.
