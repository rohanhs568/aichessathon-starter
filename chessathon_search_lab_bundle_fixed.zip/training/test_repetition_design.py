"""Deterministic tests for Chessathon repetition/draw handling.

The competition protocol passes only FEN + clock to get_move(), while the same
agent process persists across moves. Therefore a production-safe design should
maintain explicit real-game repetition counts across protocol calls rather than
assuming a FEN contains history or requiring a reconstructed move_stack to have
an exact length.

This test checks four separate things:
  1. python-chess's true threefold claim semantics on a known knight cycle;
  2. FEN-only protocol synchronization and explicit occurrence counts;
  3. exact-threefold scoring (mandatory correctness behaviour);
  4. first-cycle search-tree scoring (optional heuristic, kept separate).
"""

from __future__ import annotations

import argparse
import importlib.util
import io
import os
from contextlib import redirect_stdout
from pathlib import Path

import chess


def load_lab(path: Path, weights: Path | None):
    if weights is not None:
        os.environ["SEARCHLAB_MODEL_PATH"] = str(weights.resolve())
    spec = importlib.util.spec_from_file_location("agent_searchlab_rep", path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"could not import {path}")
    module = importlib.util.module_from_spec(spec)
    with redirect_stdout(io.StringIO()):
        spec.loader.exec_module(module)
    return module


def knight_cycle_board(cycles: int):
    board = chess.Board()
    cycle = ["g1f3", "g8f6", "f3g1", "f6g8"]
    for _ in range(cycles):
        for uci in cycle:
            move = chess.Move.from_uci(uci)
            assert move in board.legal_moves
            board.push(move)
    return board


def persist_our_known_move(lab, root: chess.Board, move_uci: str):
    """Mirror the history update done at the end of lab.get_move()."""
    move = chess.Move.from_uci(move_uci)
    assert move in root.legal_moves

    after = root.copy(stack=False)
    after.push(move)
    lab._GAME_BOARD = after.copy(stack=False)
    lab._record_game_position(lab._GAME_BOARD)
    return after


def simulate_protocol_history(lab):
    """Pretend the engine is White and receives one FEN every two plies."""
    lab.reset_searchlab_state(reset_game=True)

    actual = chess.Board()
    synced = lab._sync_game_board(actual.fen())
    assert synced.fen() == actual.fen()

    start_key = lab._rep_key(actual)
    assert lab._GAME_COUNTS.get(start_key, 0) == 1

    white_moves = ["g1f3", "f3g1", "g1f3", "f3g1"]
    black_moves = ["g8f6", "f6g8", "g8f6", "f6g8"]

    trace = []

    for ply_pair, (white_uci, black_uci) in enumerate(
        zip(white_moves, black_moves), start=1
    ):
        # Incoming root for our move. Calling sync again on the same position
        # must not increment any occurrence count.
        before_counts = dict(lab._GAME_COUNTS)
        root = lab._sync_game_board(actual.fen())
        assert root.fen() == actual.fen()
        assert lab._GAME_COUNTS == before_counts

        # Our move occurs and is recorded by the persistent agent process.
        persist_our_known_move(lab, root, white_uci)
        actual.push(chess.Move.from_uci(white_uci))
        assert lab._GAME_BOARD.fen() == actual.fen()

        # Opponent moves outside the process. The next FEN-only call must infer
        # exactly that legal reply and record the resulting position once.
        black_move = chess.Move.from_uci(black_uci)
        assert black_move in actual.legal_moves
        actual.push(black_move)

        synced = lab._sync_game_board(actual.fen())
        assert synced.fen() == actual.fen()
        assert lab._GAME_BOARD.fen() == actual.fen()

        trace.append(
            (
                ply_pair,
                len(actual.move_stack),
                lab._GAME_COUNTS.get(start_key, 0),
                sum(lab._GAME_COUNTS.values()),
            )
        )

    return actual, synced, dict(lab._GAME_COUNTS), trace


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--agent-lab",
        type=Path,
        default=Path("training/searchlab_agent.py"),
    )
    parser.add_argument("--weights", type=Path, default=Path("weights/v1.npz"))
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("repetition_design_test.txt"),
    )
    args = parser.parse_args()

    lab = load_lab(args.agent_lab, args.weights)
    lines = []

    # ------------------------------------------------------------
    # 1. Ground truth: native python-chess rule semantics.
    # ------------------------------------------------------------
    once = knight_cycle_board(1)
    twice = knight_cycle_board(2)

    start_key = lab._rep_key(chess.Board())
    once_counts = lab._build_game_counts(once)
    twice_counts = lab._build_game_counts(twice)

    assert once_counts[start_key] == 2
    assert twice_counts[start_key] == 3
    assert not once.can_claim_threefold_repetition()
    assert twice.can_claim_threefold_repetition()
    outcome = twice.outcome(claim_draw=True)
    assert outcome is not None and outcome.winner is None

    lines.append("RULE SEMANTICS: PASS")
    lines.append(
        f"starting position occurrences after one cycle: {once_counts[start_key]}"
    )
    lines.append(
        f"starting position occurrences after two cycles: {twice_counts[start_key]}"
    )
    lines.append(
        f"python-chess claim after two cycles: {twice.can_claim_threefold_repetition()}"
    )
    lines.append(f"python-chess outcome: {outcome}")
    lines.append("")

    # ------------------------------------------------------------
    # 2. FEN-only protocol reconstruction.
    # ------------------------------------------------------------
    actual, synced, protocol_counts, trace = simulate_protocol_history(lab)
    assert actual.fen() == synced.fen()
    assert protocol_counts[start_key] == 3

    # Initial position plus eight real plies means nine actual position
    # occurrences have been recorded, counting repeated boards separately.
    assert sum(protocol_counts.values()) == 9

    lines.append("FEN-ONLY PROTOCOL HISTORY RECONSTRUCTION: PASS")
    lines.append(f"actual plies simulated: {len(actual.move_stack)}")
    lines.append(
        f"starting position occurrences reconstructed: {protocol_counts[start_key]}"
    )
    lines.append(
        f"total actual position occurrences recorded: {sum(protocol_counts.values())}"
    )
    for pair, plies, start_occ, total_occ in trace:
        lines.append(
            f"  pair={pair} plies={plies} start_occurrences={start_occ} "
            f"total_occurrences={total_occ}"
        )
    lines.append("")

    # ------------------------------------------------------------
    # 3. Exact policy: true third occurrence is a draw.
    # ------------------------------------------------------------
    lab.set_searchlab_variant("repetition_exact")
    lab._GAME_COUNTS = dict(protocol_counts)
    lab._PATH_COUNTS = {}
    assert lab._is_repetition_draw(synced)

    lines.append("EXACT THREEFOLD POLICY: PASS")
    lines.append("third occurrence returns draw score 0")
    lines.append("")

    # Also prove that two real occurrences are NOT enough for exact mode.
    lab.reset_searchlab_state(reset_game=True)
    one_cycle = knight_cycle_board(1)
    lab.set_searchlab_variant("repetition_exact")
    lab._GAME_COUNTS = lab._build_game_counts(one_cycle)
    lab._PATH_COUNTS = {}
    assert not lab._is_repetition_draw(one_cycle)
    lines.append("EXACT TWO-OCCURRENCE NON-DRAW: PASS")
    lines.append("second occurrence is not incorrectly scored as threefold")
    lines.append("")

    # ------------------------------------------------------------
    # 4. Optional search-tree cycle policy.
    # ------------------------------------------------------------
    lab.reset_searchlab_state(reset_game=True)
    root = chess.Board()
    lab._GAME_COUNTS = {lab._rep_key(root): 1}
    lab._PATH_COUNTS = {}
    lab.set_searchlab_variant("repetition_cycle")

    path_board = root.copy(stack=False)
    for uci in ["g1f3", "g8f6", "f3g1", "f6g8"]:
        move = chess.Move.from_uci(uci)
        assert move in path_board.legal_moves
        lab._rep_push(path_board, move)

    # Compare repetition-relevant board state, not full FEN counters.
    assert lab._rep_key(path_board) == lab._rep_key(root)
    assert lab._is_repetition_draw(path_board)

    lines.append("SEARCH-TREE FIRST-CYCLE POLICY: PASS")
    lines.append("second occurrence inside current search is treated as 0")
    lines.append("")

    lines.append("IMPORTANT")
    lines.append("---------")
    lines.append(
        "Exact threefold and first-cycle scoring are intentionally separate policies."
    )
    lines.append(
        "Exact threefold tracking is a correctness requirement. First-cycle scoring is"
    )
    lines.append(
        "a search heuristic and must be A/B tested before entering the tournament agent."
    )

    args.output.write_text("\n".join(lines) + "\n")
    print(args.output.read_text())


if __name__ == "__main__":
    main()
